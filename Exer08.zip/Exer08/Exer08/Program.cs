﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int inicio = 1;
            int final = 100;
            int soma = 0;

            for (int i = inicio; i <= final; i++)
            {
                soma = soma + i;
            }
            Console.WriteLine(soma);
        }
    }
}
