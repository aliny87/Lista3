﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n;
            int x;
            int c;

            do
            {
                Console.Clear();
                Console.WriteLine(" Digitar dois valor: vale lembrar que o  2º valor > 1º valor");
                Console.WriteLine(" primeiro valor");
                n = int.Parse(Console.ReadLine());
                Console.WriteLine(" segundo valor");
                x = int.Parse(Console.ReadLine());

            }
            while (n > x);
            Console.WriteLine("Voce Digitou os valores validos!!");
        }
    }
}
