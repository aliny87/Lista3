﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n;
            int x;
            int c;

            do
            {
                Console.Clear();
                Console.WriteLine("Digite dois valores,lembrando que 2º > 1º");
                Console.WriteLine("primeiro valor");
                n = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("segundo valor");
                x = Convert.ToInt16(Console.ReadLine());
            }
            while (n > x);
            Console.WriteLine("Qual o intervalo que o programa deve calcular sua tabuada?");
            c = int.Parse(Console.ReadLine());

            for (int f = 1; f <= c; f++)
            {
                Console.WriteLine(n + "x"  + f +  "=" + f );

            }
            Console.Read();
        }
    }
}
